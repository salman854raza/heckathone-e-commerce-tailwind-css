const HomePage = () => {
  return (
    <div className=''>HomePage</div>
  )
}

export default HomePage