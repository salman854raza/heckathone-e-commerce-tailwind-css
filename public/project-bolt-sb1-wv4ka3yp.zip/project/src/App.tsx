import React from 'react';
import { ShopPage } from './components/Shop/ShopPage';

function App() {
  return <ShopPage />;
}

export default App;