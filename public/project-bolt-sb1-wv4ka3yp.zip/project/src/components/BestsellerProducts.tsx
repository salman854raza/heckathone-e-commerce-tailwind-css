import React from 'react';
import { ProductCard } from './ProductCard';
import { bestsellerProducts } from '../data/products';

export const BestsellerProducts: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">BESTSELLER PRODUCTS</h2>
      <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4">
        {bestsellerProducts.map((product) => (
          <ProductCard key={product.id} {...product} />
        ))}
      </div>
    </div>
  );
}