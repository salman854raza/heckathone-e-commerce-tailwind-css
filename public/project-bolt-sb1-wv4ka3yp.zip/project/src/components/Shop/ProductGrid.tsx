import React from 'react';
import { ProductCard } from './ProductCard';

const products = Array(12).fill(null).map((_, index) => ({
  id: index + 1,
  title: 'Graphic Design',
  department: 'English Department',
  originalPrice: 16.48,
  salePrice: 6.48,
  image: `/product-${index + 1}.jpg`,
  colors: ['blue', 'green', 'orange', 'navy']
}));

export const ProductGrid: React.FC = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
      {products.map((product) => (
        <ProductCard key={product.id} {...product} />
      ))}
    </div>
  );
};