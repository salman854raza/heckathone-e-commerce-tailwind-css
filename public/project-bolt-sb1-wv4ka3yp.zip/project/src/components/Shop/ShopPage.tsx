import React from 'react';
import { Navbar } from './Navbar';
import { CategoryBanner } from './CategoryBanner';
import { ProductGrid } from './ProductGrid';
import { Pagination } from './Pagination';

export const ShopPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <div className="container mx-auto px-4 py-8">
          <CategoryBanner />
          <ProductGrid />
          <Pagination />
        </div>
      </main>
    </div>
  );
};