import React from 'react';

export const SocialLinks: React.FC = () => {
  return (
    <div className="flex space-x-6">
      <SocialIcon href="#" icon="twitter" />
      <SocialIcon href="#" icon="facebook" />
      <SocialIcon href="#" icon="instagram" />
      <SocialIcon href="#" icon="linkedin" />
    </div>
  );
};

const SocialIcon: React.FC<{ href: string; icon: string }> = ({ href, icon }) => (
  <a
    href={href}
    className="text-gray-900 hover:text-blue-500 transition-colors"
  >
    <span className="sr-only">{icon}</span>
    <i className={`fab fa-${icon} text-2xl`} />
  </a>
);