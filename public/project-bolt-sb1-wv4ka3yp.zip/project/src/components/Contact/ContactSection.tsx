import React from 'react';
import { SocialLinks } from './SocialLinks';

export const ContactSection: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-gray-600 uppercase tracking-wide">CONTACT US</h2>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900">
          Get in touch today!
        </h1>
      </div>

      <p className="text-gray-600 text-lg">
        We know how large objects will act, but things on a small scale
      </p>

      <div className="space-y-4">
        <div className="space-y-1">
          <p className="text-gray-900 font-medium">Phone</p>
          <p className="text-gray-600">+451 215 215</p>
        </div>
        <div className="space-y-1">
          <p className="text-gray-900 font-medium">Fax</p>
          <p className="text-gray-600">+451 215 215</p>
        </div>
      </div>

      <SocialLinks />
    </div>
  );
};