import React from 'react';
import { Navbar } from './Navbar';
import { ContactSection } from './ContactSection';
import { SocialLinks } from './SocialLinks';

export const ContactPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="container mx-auto px-4 py-12 md:py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <ContactSection />
          <div className="relative">
            <div className="absolute top-0 right-0 w-3/4 h-3/4 bg-pink-100 rounded-full -z-10" />
            <img
              src="/family-shopping.jpg"
              alt="Family shopping"
              className="relative z-10 w-full h-auto rounded-lg"
            />
          </div>
        </div>
      </main>
    </div>
  );
};