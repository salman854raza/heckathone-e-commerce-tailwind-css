import React from 'react'

export default function AboutSection2() {
  return (
    <div>
      
    </div>
  )
}
